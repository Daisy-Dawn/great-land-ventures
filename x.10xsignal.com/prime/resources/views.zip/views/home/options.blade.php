@extends('layouts.base')




@inject('content', 'App\Http\Controllers\FrontController')
@section('content')
<!-- =============================Wrapper========================================================== -->
<section class="wrapper">

    <section class="container-fluid bg-market">
          <div class="row">
            <div class="col-6 abt-us-txt">
              <h2 class="p-20 white">  Option  </h2>
            </div>

       
          </div>

          <!-- the body section that contain the text =============== -->
          
        </section>
    <!-- ============BREADCUMB================== -->
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/" class="lite-ash">Home</a></li>  
        <li class="breadcrumb-item active" aria-current="page">shares</li>
      </ol>
    </nav>
    <br>
    <section class="container-fluid">
      <div class="row">
        <div class="col-md-8 col-sm-12 col-crypto">
          <div class="container">
            <br />
            <h2 class="text-right t-h2"> Options </h2>

            <img src="{{$settings->site_address}}/public/images/item-options.png" >
            <div style="padding: 20px;">
              <h3> <b> Options </b></h3>
              <p class="t-p">These are contracts that gives the owner the right to buy or sell an asset at a fixed price, called the strike price, for a specific period of time. The “asset” may be several kinds of underlying securities. Some of the most common ones are stocks, indexes, or ETFs. That period of time could be as short as a day or as long as a couple of years, depending on the option. The seller of the option contract receives the payment from the buyer and then takes on an obligation to take the opposite side of the trade if the owner chooses to buy or sell the asset. Keep in mind, we don’t charge a fee for closing options positions that are 5¢ or below..</p>
              <br />
            

              

              <p>Discover all the advantages of trading with {{$settings->site_name}}:</p>
              <br />
              <ul class="crypto-list">
                <li> <i class="fas fa-arrow-right"></i> <b> Start trading with as little as $500</b> </li>
                <li> <i class="fas fa-arrow-right"></i> <b>Benefit from a wide range of today’s top traded cryptocurrencies. </b></li>
                <li> <i class="fas fa-arrow-right"></i> <b>No risk of wallet hacking or theft  </b> </li>
                <li> <i class="fas fa-arrow-right"></i> <b> Around-the-clock service</b> </li>
              </ul>

         
              
            </div>
          </div> <!-- end container -->
          
          
          
        </div> <!-- end column-->

        <div class="col-md-4 col-sm-12">
          <div class="pad-55"></div>
          <div class="container">
            <div class="crypto-cat">
              <a href="crypto"> <div> Cryptocurrencies</div> </a>
              <a href="indices"> <div> Indices</div> </a>
              <a href="forex"> <div> Forex</div> </a>
              <a href="commodities"> <div> Commodities</div> </a>
              <a href="shares"> <div> Shares</div> </a>
              <div class="current-crypto">  <p> <i class="fas fa-arrow-alt-circle-right"></i> &nbsp Options</p></div>
              <a href="etfs"> <div> ETFs</div> </a>
              <br />


             <div class="crypto-form"> 
                <h3 class="text-center"> Have a Question?  </h3>
                <form>
                <div class="form-group">
                  <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Your Name">
                </div>

                <div class="form-group">
                  <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Email*">
                </div>

                 <div class="form-group">
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                  </div>

                <button type="submit" class="plan-signup-crypto">Submit</button>
              </form>
              </div>            </div>
            
          </div>

              
        </div> <!-- end the container --> 

        
      </div><!-- end row -->
      
    </section>

    @endsection