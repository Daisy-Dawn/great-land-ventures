
@extends('layouts.base')



@inject('content', 'App\Http\Controllers\FrontController')
@section('content')
      

<div class="clearfix"></div>

<!-- this is the design of the slider  -->
<section class="single-item">

  <div class="slider-img1">
    <div class="row">
      <div class="col-md-6 col-sm-12">

        <h1 class="slide-h1" data-aos="fade-up"> 
          <span style="font-weight: 700"> Highly Qualified <br />
           Customer Support Department  </span> 
        </h1>


        <p class="display-none-mobile">
         Boost your profits with the power of 100X leverage. Go Long/Short on a secure and ultra-fast platform.
        </p>

  
     
  
        <a href="trade">
          <div class="create-acc c-sign-up">
            <img src="{{$settings->site_address}}/public/images/icon/b-chart.png" class="float-left"> <p> View Live Trade  </p>
          </div>
        </a>
<div class="p-20"> </div>
     
         <br />

        <div class="learn-btc">
          <button class="play-btn float-left" type="button" data-toggle="modal" data-target="#exampleModalCenter">
            <img src="{{$settings->site_address}}/public/images/icon/play-button.svg" >
          </button>

          <span> Click here to learn about bictoin </span>
        </div>




    
        
      </div>

      <!-- =====end the left section of the first slider ===== -->

         <!-- start of the tool widget area for this section  -->
      <div class="col-md-6 col-sm-12 nav-back mobile-none">

            <!-- TradingView Widget BEGIN -->
        <div class="tradingview-widget-container ">
          <div class="tradingview-widget-container__widget display-none-mobile" ></div>
         
          <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-market-overview.js" async>
          {
          "colorTheme": "dark",
          "dateRange": "12m",
          "showChart": true,
          "locale": "en",
          "largeChartUrl": "",
          "isTransparent": true,
          "width": "100%",
          "height": "500",
          "plotLineColorGrowing": "rgba(25, 118, 210, 1)",
          "plotLineColorFalling": "rgba(25, 118, 210, 1)",
          "gridLineColor": "rgba(42, 46, 57, 1)",
          "scaleFontColor": "rgba(120, 123, 134, 1)",
          "belowLineFillColorGrowing": "rgba(33, 150, 243, 0.12)",
          "belowLineFillColorFalling": "rgba(33, 150, 243, 0.12)",
          "symbolActiveColor": "rgba(33, 150, 243, 0.12)",
          "tabs": [
            {
              "title": "Indices",
              "symbols": [
                {
                  "s": "OANDA:SPX500USD",
                  "d": "S&P 500"
                },
                {
                  "s": "OANDA:NAS100USD",
                  "d": "Nasdaq 100"
                },
                {
                  "s": "FOREXCOM:DJI",
                  "d": "Dow 30"
                },
                {
                  "s": "INDEX:NKY",
                  "d": "Nikkei 225"
                },
                {
                  "s": "INDEX:DEU30",
                  "d": "DAX Index"
                },
                {
                  "s": "OANDA:UK100GBP",
                  "d": "FTSE 100"
                }
              ],
              "originalTitle": "Indices"
            },
            {
              "title": "Commodities",
              "symbols": [
                {
                  "s": "CME_MINI:ES1!",
                  "d": "E-Mini S&P"
                },
                {
                  "s": "CME:6E1!",
                  "d": "Euro"
                },
                {
                  "s": "COMEX:GC1!",
                  "d": "Gold"
                },
                {
                  "s": "NYMEX:CL1!",
                  "d": "Crude Oil"
                },
                {
                  "s": "NYMEX:NG1!",
                  "d": "Natural Gas"
                },
                {
                  "s": "CBOT:ZC1!",
                  "d": "Corn"
                }
              ],
              "originalTitle": "Commodities"
            },
            {
              "title": "Bonds",
              "symbols": [
                {
                  "s": "CME:GE1!",
                  "d": "Eurodollar"
                },
                {
                  "s": "CBOT:ZB1!",
                  "d": "T-Bond"
                },
                {
                  "s": "CBOT:UB1!",
                  "d": "Ultra T-Bond"
                },
                {
                  "s": "EUREX:FGBL1!",
                  "d": "Euro Bund"
                },
                {
                  "s": "EUREX:FBTP1!",
                  "d": "Euro BTP"
                },
                {
                  "s": "EUREX:FGBM1!",
                  "d": "Euro BOBL"
                }
              ],
              "originalTitle": "Bonds"
            },
            {
              "title": "Forex",
              "symbols": [
                {
                  "s": "FX:EURUSD"
                },
                {
                  "s": "FX:GBPUSD"
                },
                {
                  "s": "FX:USDJPY"
                },
                {
                  "s": "FX:USDCHF"
                },
                {
                  "s": "FX:AUDUSD"
                },
                {
                  "s": "FX:USDCAD"
                }
              ],
              "originalTitle": "Forex"
            }
          ]
        }
          </script>
        </div>
        <!-- TradingView Widget END -->
      </div>

    </div>
    <!-- ===========End Row here ======================= -->
    
  </div>
  <!-- this is the end of the slider of each section  -->


   <div class="slider-img2">
    <div class="row">
      <div class="col-md-5 col-sm-12" data-aos="fade-righ">

        <h1 class="slide-h1" data-aos= "fade-down"> 
          <span style="font-weight: 700"> RELIABLE, SIMPLE AND INNOVATIVE 
        </h1>


        <p class="display-none-mobile">
        Trade Cryptocurrencies, Stock indexes, Commodities and Forex with a single with this platform
        </p>

  
        <div class="p-20"> </div>
  
        <a href="login">
          <div class="create-acc c-sign-up">
            <img src="{{$settings->site_address}}/public/images/icon/b-chart.png" class="float-left"> <p> Login  </p>
          </div>
        </a>

    
        
      </div>

      <!-- =====end the left section of the first slider ===== -->

         <!-- start of the tool widget area for this section  -->
      <div class="col-md-7 col-sm-12 ">

         <img src="{{$settings->site_address}}/public/images/slider/slider.png">
      </div>

    </div>
    <!-- ===========End Row here ======================= -->
    
  </div>
  <!-- this is the end of the slider of each section  -->



   <div class="slider-img3">
    <div class="row">
      <div class="col-md-5 col-sm-12">  


        <h1 class="slide-h1">One Low Fee More Great  <br />
          <span style="font-weight: 600">Trading With {{$settings->site_name}} </span> 
        </h1>


       <p class="display-none-mobile">
          Find your trading opportunity in 3 easy steps
        </p>

        <ul class = "slider-li">
          <li> <i class="fas fa-check" style="color: #52afee"> </i>  &nbsp  Open Account</li>
          <li>  <i class="fas fa-check" style="color: #52afee"> </i>  &nbsp Deposit </li>
          <li> <i class="fas fa-check" style="color: #52afee"> </i>  &nbsp Start Trading </li>
        </ul>

  
       <br />
  
        <a href="register">
          <div class="create-acc lt-blue-bg">
            <img src="{{$settings->site_address}}/public/images/icon/b-chart.png" class="float-left"> <p> Start Earning  </p>
          </div>
        </a>

    
        
      </div>

      <!-- =====end the left section of the first slider ===== -->

         <!-- start of the tool widget area for this section  -->
       <div class="col-md-7 col-sm-12 ">

         <img src="{{$settings->site_address}}/public/images/slider/3-Assets.png">
      </div>

    </div>
    <!-- ===========End Row here ======================= -->
    
  </div>
  <!-- this is the end of the slider of each section  -->

</section>
<!-- ===========================================end the section slider ============================ -->



              <!-- TradingView Widget BEGIN -->
        <div class="tradingview-widget-container">
          <div class="tradingview-widget-container__widget"></div>
          <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/" rel="noopener" target="_blank"><span class="blue-text">Market Data</span></a> by TradingView</div>
          <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-market-overview.js" async>
          {
          "colorTheme": "dark",
          "dateRange": "12m",
          "showChart": true,
          "locale": "en",
          "largeChartUrl": "",
          "isTransparent": true,
          "width": "100%",
          "height": "500",
          "plotLineColorGrowing": "rgba(25, 118, 210, 1)",
          "plotLineColorFalling": "rgba(25, 118, 210, 1)",
          "gridLineColor": "rgba(42, 46, 57, 1)",
          "scaleFontColor": "rgba(120, 123, 134, 1)",
          "belowLineFillColorGrowing": "rgba(33, 150, 243, 0.12)",
          "belowLineFillColorFalling": "rgba(33, 150, 243, 0.12)",
          "symbolActiveColor": "rgba(33, 150, 243, 0.12)",
          "tabs": [
            {
              "title": "Indices",
              "symbols": [
                {
                  "s": "OANDA:SPX500USD",
                  "d": "S&P 500"
                },
                {
                  "s": "OANDA:NAS100USD",
                  "d": "Nasdaq 100"
                },
                {
                  "s": "FOREXCOM:DJI",
                  "d": "Dow 30"
                },
                {
                  "s": "INDEX:NKY",
                  "d": "Nikkei 225"
                },
                {
                  "s": "INDEX:DEU30",
                  "d": "DAX Index"
                },
                {
                  "s": "OANDA:UK100GBP",
                  "d": "FTSE 100"
                }
              ],
              "originalTitle": "Indices"
            },
            {
              "title": "Commodities",
              "symbols": [
                {
                  "s": "CME_MINI:ES1!",
                  "d": "E-Mini S&P"
                },
                {
                  "s": "CME:6E1!",
                  "d": "Euro"
                },
                {
                  "s": "COMEX:GC1!",
                  "d": "Gold"
                },
                {
                  "s": "NYMEX:CL1!",
                  "d": "Crude Oil"
                },
                {
                  "s": "NYMEX:NG1!",
                  "d": "Natural Gas"
                },
                {
                  "s": "CBOT:ZC1!",
                  "d": "Corn"
                }
              ],
              "originalTitle": "Commodities"
            },
            {
              "title": "Bonds",
              "symbols": [
                {
                  "s": "CME:GE1!",
                  "d": "Eurodollar"
                },
                {
                  "s": "CBOT:ZB1!",
                  "d": "T-Bond"
                },
                {
                  "s": "CBOT:UB1!",
                  "d": "Ultra T-Bond"
                },
                {
                  "s": "EUREX:FGBL1!",
                  "d": "Euro Bund"
                },
                {
                  "s": "EUREX:FBTP1!",
                  "d": "Euro BTP"
                },
                {
                  "s": "EUREX:FGBM1!",
                  "d": "Euro BOBL"
                }
              ],
              "originalTitle": "Bonds"
            },
            {
              "title": "Forex",
              "symbols": [
                {
                  "s": "FX:EURUSD"
                },
                {
                  "s": "FX:GBPUSD"
                },
                {
                  "s": "FX:USDJPY"
                },
                {
                  "s": "FX:USDCHF"
                },
                {
                  "s": "FX:AUDUSD"
                },
                {
                  "s": "FX:USDCAD"
                }
              ],
              "originalTitle": "Forex"
            }
          ]
        }
          </script>
        </div>
        <!-- TradingView Widget END -->

      


<!-- the first column starts here  -->
<section class="container">


<!-- ==========================Modal ===================================-->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle"> Learn About Forex</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="desktop-wrapper">
          <iframe src="https://www.youtube.com/embed/Gc2en3nHxA4" allow="autoplay; encrypted-media" allowfullscreen="" width="560" height="315" frameborder="0"></iframe>
        </div>
        ...
      </div>
    
    </div>
  </div>
</div>
 <!-- ==========================Modal ===================================-->
   <!-- <link rel="stylesheet" href="aos/styles.css" /> -->
<link rel="stylesheet" href="aos/dist/aos.css" />
  
</section> <!-- end the first colunm section of the wrapper -->

<!-- ========================================this is the step in registeration section ================================== -->

<section class = "container"> 
  <h3 class = "text-center" data-aos="fade-right"> How it works </h3>
  <br />

  <div class = "container how-it-work" data-aos="fade-up">

    <div class = "row">

        <div class ="col-md-4 col-sm-12 how-it-work-inner">
            <h5> <span> <img src ="{{$settings->site_address}}/public/images/icon/deposit.svg"> </span> Deposit</h5>
            <p class = "lite-ash">
            Open real account and add funds. We work with more than 20 payment systems.
            </p>

        </div>

        <div class ="col-md-4 col-sm-12 how-it-work-inner">
            <h5> <span> <img src ="{{$settings->site_address}}/public/images/icon/choose.svg"> </span> Trade</h5>
            <p class = "lite-ash">
            Trade any of 100 assets and stocks. Use technical analysis and trade the news
            </p>

        </div>

        <div class ="col-md-4 col-sm-12 how-it-work-inner">
            <h5> <span> <img src ="{{$settings->site_address}}/public/images/icon/withdraw-small.svg"> </span> Withdraw</h5>
            <p class = "lite-ash">
            Get funds easily to your bank card or e-wallet. We take no commission.
            </p>

        </div>
        <div class ="col-md-4 col-sm-12 how-it-work-inner">
            <h5> <span> <img src ="{{$settings->site_address}}/public/images/icon/keypad.svg"> </span> Safe and secure</h5>
            <p class = "lite-ash">
            We take careful measures to ensue that your personal to ensure that your personal details is as safe as possible.offline storage provides an important security measure against theft $ loss
            </p>

        </div>
        
    </div>

  </div>

</section>

<!-- ========================================ENDS HERE this is the step in registeration section ================================== -->


<!-- =======================================features section ========================================================== -->
<section class = "container" data-aos="fade-up"> 
<h1> 
  <span>
    <img src = "{{$settings->site_address}}/public/images/icon/features.svg">
  </span>
  Features
</h1>

<div class = "row">
  <div class = "col-md-6 col-sm-12"> 
   <p class = "lite-ash"> 
    We provide fastest trading using modern technologies. No delays in order executions and most accurate quotes. Our trading platform is available around the clock and on weekends. 
    {{$settings->site_name}} customer service is available 24/7. We are continuously adding new financial instruments. 
   </p>
  </div>
  <!-- end column here  -->

  <div class = "col-md-6 col-sm-12"> 
    <ul class = "lite-ash features-list">
      <li> Technical analysis tools: 4 chart types, 8 indicators, trend lines  </li>
      <li> Social trading: watch deals across the globe or trade with your friends  </li>
      <li> Over 100 assets including popular stocks  </li>
      
    </ul>
  
  </div>
  <!-- end column here  -->
</div>
<!-- end row div here  -->

</section>


<!-- ======================================= END features section ========================================================== -->

<!-- ======================================== card features section ============================================== -->
<section class = "card-layer">



  <div class = "ft-card-1 mobile-none" data-aos="fade-up">  </div>
  

<!-- ===================== -->


  <div class = "ft-card-2" data-aos="fade-up">  </div>

<!-- ===================== -->


  <div class = "ft-card-3 mobile-none" data-aos="fade-up">  </div>

<!-- ===================== -->

</div>
<!-- end row here  -->
</section>

<!-- ========================================END  card features section ============================================== -->

<section class="container" >
  <div class="row">
    
    <div class="col-md-6 col-sm-12" data-aos="fade-right"> 
      <h1> Trade Forex, S&P 500, Gold, EURUSD and <br />
        30+ assets
      </h1>

      <p> 
        Get immediate access to cryptocurrencies, stock indices, commodities and forex with a single Forex-based platform
      </p>

      <a href="register">
        <button type="button" class="btn btn-primary">Open Account For Free </button> 
      </a>
      <br />
   

      

    </div> <!-- end col -->

    <div class="col-md-6 col-sm-12 trade-instr table-responsive" data-aos="fade-left">
      <table class="table in-table lite-ash">

        <thead>
          <tr>
            <th scope="col">Instrument</th>
            <th scope="col">Leverage</th>
            <th scope="col">Instrument</th>
            <th scope="col">Leverage</th>
          </tr>
        </thead>

        <tbody>

          <tr class="ash-bg">

            <td> <img src="{{$settings->site_address}}/public/images/icon/instruments/btc.svg" alt="Bitcoin" class="m-4-neg"> <span> Bitcoin </span> </td>
            <td>100X</td>
            <td> <img src="{{$settings->site_address}}/public/images/icon/instruments/btc.svg" alt="fx" class="m-4-neg">  EURUSD </td>
            <td> 1000X </td>

          </tr>

          <tr class="lite-ash-bg">
            
            <td> <img src="{{$settings->site_address}}/public/images/icon/instruments/eth.svg" alt="Ethereum " class="m-4-neg"> <span> Ethereum</span> </td>
            <td>100X</td>
            <td> <img src="{{$settings->site_address}}/public/images/icon/instruments/graph.svg" alt="S&P 500" class="m-4-neg">  S&P 500 </td>
            <td> 100X </td>

          </tr>

          <tr class="ash-bg">

            <td> <img src="{{$settings->site_address}}/public/images/icon/instruments/ltc.svg" alt="Litecoin" class="m-4-neg"> <span> Litecoin </span> </td>
            <td>100X</td>
            <td> <img src="{{$settings->site_address}}/public/images/icon/instruments/gold.svg" alt="GOLD" class="m-4-neg">  GOLD </td>
            <td> 5000X </td>

          </tr>

           <tr class="lite-ash-bg">
            
            <td> <img src="{{$settings->site_address}}/public/images/icon/instruments/ripple.svg" alt="Ripple " class="m-4-neg"> <span> Ripple</span> </td>
            <td>100X</td>
            <td> <img src="{{$settings->site_address}}/public/images/icon/instruments/oil.svg" alt="CRUDE OIL" class="m-4-neg">  CRUDE OIL </td>
            <td> 100X </td>

             <tr class="ash-bg">

            <td> <img src="{{$settings->site_address}}/public/images/icon/instruments/ltc.svg" alt="EOS" class="m-4-neg"> <span> EOS </span> </td>
            <td>100X</td>
            <td> <img src="{{$settings->site_address}}/public/images/icon/instruments/graph.svg" alt="JAPAN" class="m-4-neg">  JAPAN </td>
            <td> 5000X </td>

          </tr>

          </tr>

        </tbody>
      </table>

      <a href="trade.php" class="text-center lite-ash"> See all assets </a>
      
    </div>
  </div> <!-- end row -->      
</section>
<!-- ================================================End of the first SEction ======================================= -->
<div class="p-20"> </div> 
<!-- to clear space -->




<!-- account set up  -->


<div class="m-20"  data-aos="fade-up">
  <center>
       <a href="register">
        <button type="button" class="btn btn-primary">Setup Your Trading Account </button> 
      </a>
  </center>

      <br />

  <p class="text-center"> It only takes 40 seconds. No KYC required.</p>
</div>

<div data-aos="fade-up" style="height:560px; background-color: #1D2330; overflow:hidden; box-sizing: border-box; border: 1px solid #282E3B; border-radius: 4px; text-align: right; line-height:14px; font-size: 12px; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #262B38;padding:1px;padding: 0px; margin: 0px; width: 100%;"><div style="height:540px; padding:0px; margin:0px; width: 100%;"><iframe src="https://widget.coinlib.io/widget?type=chart&theme=dark&coin_id=859&pref_coin_id=1505" width="100%" height="536px" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;line-height:14px;"></iframe></div><div style="color: #626B7F; line-height: 14px; font-weight: 400; font-size: 11px; box-sizing: border-box; padding: 2px 6px; width: 100%; font-family: Verdana, Tahoma, Arial, sans-serif;"><a href="https://coinlib.io" target="_blank" style="font-weight: 500; color: #626B7F; text-decoration:none; font-size:11px">Cryptocurrency Prices</a>&nbsp;by Coinlib</div></div>


      <!-- ============================================================================================================================ -->
  <div class="tradingview-widget-container__widget"></div>
        <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-forex-cross-rates.js" async>
        {
        "width": "100%",
        "height": "400",
        "colorTheme": "dark",
        "currencies": [
          "EUR",
          "USD",
          "JPY",
          "GBP",
          "CHF",
          "AUD",
          "CAD",
          "NZD",
          "CNY"
        ],
        "locale": "en"
      }
        </script>
      </div>
      <!-- TradingView Widget END -->

  <!-- ============================================================================================================================ -->


  <!-- ============================================================================================================================ -->

 

  <!--  ==================================this is the VIP BLACK section page  ==============================-->
<section class="container-fluid abt-body">
  <div class="container">
    <h2> Profit from Market Ups & Downs </h2>
    <div class="row">



      <div class="col-md-4 col-sm-12 p-20">
        <div class="p-chart">
          <img src="{{$settings->site_address}}/public/images/higher-chart.svg">
        </div>
       
            
      </div> <!-- end div-->

      <div class="col-md-4 col-sm-12">
        <div class="">
            <p class="white p-text"> 
              {{$settings->site_name}} allows you to actively trade most popular cryptocurrencies such as Bitcoin, Ethereum, Ripple, Litecoin and more, profit from market rallies 
              and declines, or hedge your existing cryptocurrency holdings
            </p>

            <a href="register">
              <button type="button" class="btn btn-primary">Setup Your Trading Account </button> 
            </a>
        </div>
        
      </div> <!-- end div -->

      <div class="col-md-4 col-sm-12 p-20">
        <div class="p-chart">
          <img src="{{$settings->site_address}}/public/images/lower-chart.svg">
        </div>
       
            
      </div> <!-- end div-->

     
    </div>
    
  </div>
  <div style="padding: 20px"></div>
</section>
<!-- end the about us section  -->
<!--  four column section with choose a package section  -->
    <section class="container-fluid " data-aos="fade-down">
      <h3 style="text-align: center;" data-aos="fade-right"> Our Trading Account Types </h3>

  





<div class="container-fluid" data-aos="fade-right">
    <div class="row" style="padding: 20px;">
    	@foreach ($plans as $plan)
      <div class="col-lg-3 col-md-6 col-sm-12 plan-wrap" data-aos="fade-left">
        <div class="col-plan-inner">
          <div class="col-plan-head">
            <h2 class="pt-4"> {{ $plan->name }} </h2>
            <b class="h4 font-weight-bold">{{$plan->increment_amount}}%  {{$plan->increment_interval}}</b><br>
            <span class="lt-blue"> <b></b> </span>
            <p> &nbsp;</p>
          </div>
          

           <div class="min-price" data-aos="fade-down">
            <b class="h4">Minimum Deposit:</b><br>
            <span class="lt-blue"> <b class="h4" >{{$settings->currency}}{{$plan->min_price}}</b> </span>
          </div>
          
          <div class="min-price">
            <b class="h4">Maximum Deposit:</b><br>
            <span class="lt-blue"> <b class="h4">{{$settings->currency}}{{$plan->max_price}}</b> </span>
          </div>
           <!-- those values ontop of the .... -->
          <div class="clearfix"></div>


            <br />
        
         
          <a href="register">
           <div class="plan-signup">
            <center class="h4">
              Sign up &nbsp 
            </center>
            
          </div>
           </a>
      
         
        </div>
        
      </div> 
       @endforeach
    </section>
    <!-- end main container -->
  
</section> <!-- end wrapper -->
<!-- ======================================this is the section that has the embeded video ====================================== -->

<!-- This is the section that contain the trading widget  -->

<!-- ======================================================this is the count tis section ========================================= -->
<section class="container-fluid col-testimony">
<!-- ==========================================this is the Payment Methods section=========================================== -->
<div class="container col-pay-meth">
  <h5 class="text-center"> WE ACCEPT </h5>
  <p class="text-center white"> Payment Methods for Deposit and withdrawal </p>
  <div class="row">
    <div class="col-md-3 col-sm-6">
      <img src="{{$settings->site_address}}/public/images/ethereum.png">
    </div> <!-- end colunm -->

    <div class="col-md-3 col-sm-6">
      <img src="{{$settings->site_address}}/public/images/bitcoin.png">
    </div> <!-- end colunm -->

    <div class="col-md-3 col-sm-6">
      <img src="{{$settings->site_address}}/public/images/litecoin.png">
    </div> <!-- end colunm -->

    <div class="col-md-3 col-sm-6">
      <img src="{{$settings->site_address}}/public/images/perfect-money.png">
    </div> <!-- end colunm -->

    <!-- =============================== The payment methods section ends here --- ============================-->

    
  </div> <!-- end row-->


  

</div><!-- end container -->

<!--==================== the coutis section starts here ========================= -->
 

 
</section>



   <!-- =========================this is the testimony section ========================== -->
   <section class="col-testimony-bg">
       <!-- end of the container fluid -->
      
         <a href = "video-testimony" target= "_blank"> 
         <div class="view-vid">
          <button class="play-btn float-left" type="button" >
            <img src="{{$settings->site_address}}/public/images/icon/play-button.svg" >
          </button>

          <span> Click here to view video Testimony</span>
        </div>
     
     </a> 
     <div class = "clear-fix"> </div>
     

         <!-- ========================================================= start latest Trade option ===================================================== -->
        <!-- ===============================DESPOSIT SECTION ============================== -->

      
        
       <section>

    <div class="container-fluid  table-responsive" style="margin-left:-4px">
        <div class="row">
            <div class="col-md-6">
                <h2 class="home-title">Recent <span class="yellow"> Withdrawals and Payouts</span></h2>
                <!-- <h2></h2> -->
                 <!-- <p> XTBOptions ensures that you never miss out on a trading opportunity with a fully functional mobile site that has all of the features of the desktop so you can easily trade currencies, commodities, stocks and indices, wherever you are, whenever you desire. Just simply type XTBOptions.com into the web browser of your iPhone, Android or tablet device, log into your  XTBOptions account and start trading immediately.
                 </p> -->
            </div>
  

                <div class="col-md-12" id="payOut">
                    <table class="table table-bordered rank">
                    <thead class="thead-dark">
                        <tr>
                            <th>USER ID</th>
                            <th>PAYMENT METHOD</th>
                            <th>AMOUNT</th>
                            <th>DATE</th>
                        </tr>
                    </thead>
                    
<script>
var paymentMethod = ["Wire transfer","Bitcoin","Skrill","Western union" ];
     function ramdomPaymentMethod(){
    var Item = paymentMethod[Math.floor(Math.random()*paymentMethod.length)];
    return Item;
}

</script>

<script>
function generateAmount(length = 5) {
       var result           = '';
       var characters       = '123456789';
       var charactersLength = characters.length;
       for ( var i = 0; i < length; i++ ) {
          result += characters.charAt(Math.floor(Math.random() * charactersLength));
       }
       return "$ " + result.toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ",");
         }
         
</script>
                    <tbody>
                        <font color="white">
                        <tr>
                            <td class="auto-style1">User_36649</td>
                            <td class="auto-style1" ><script>document.write(ramdomPaymentMethod());</script></td>
                            <td class="auto-style1" ><script>document.write(generateAmount());</script></td>
                            <td id='DATE' class="auto-style1">
                                <script>
                                    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                var day = currentDate.getDate() - 1
                var month = currentDate.getMonth() + 1
                var year = currentDate.getFullYear()
                document.write("<b>" + day + "/" + month + "/" + year + "</b>")
                                </script>
                                </td>
                        </tr></font>
                        <tr>
                            <td class="auto-style1">User_68681</td>
                            <td class="auto-style1"><script>document.write(ramdomPaymentMethod());</script></td>
                            <td class="auto-style1">$ 24,099</td>
                            <td id='DATE' class="auto-style1">
                                
                                <script>
                                    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                var day = currentDate.getDate() - 1
                var month = currentDate.getMonth() + 1
                var year = currentDate.getFullYear()
                document.write("<b>" + day + "/" + month + "/" + year + "</b>")
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <td class="auto-style1">User_70876</td>
                            <td class="auto-style1"><script>document.write(ramdomPaymentMethod());</script></td>
                            <td class="auto-style1">$ 12,350</td>
                            <td id='DATE' class="auto-style1">
                                <script>
                                    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                var day = currentDate.getDate() - 1
                var month = currentDate.getMonth() + 1
                var year = currentDate.getFullYear()
                document.write("<b>" + day + "/" + month + "/" + year + "</b>")
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <td class="auto-style1">User_29050</td>
                            <td class="auto-style1"><script>document.write(ramdomPaymentMethod());</script></td>
                            <td class="auto-style1">$ 4,053</td>
                            <td id='DATE' class="auto-style1">
                                <script>
                                    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                var day = currentDate.getDate() - 1
                var month = currentDate.getMonth() + 1
                var year = currentDate.getFullYear()
                document.write("<b>" + day + "/" + month + "/" + year + "</b>")
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <td class="auto-style1">User_61809</td>
                            <td class="auto-style1"><script>document.write(ramdomPaymentMethod());</script></td>
                            <td class="auto-style1">$ 14,741</td>
                            <td id='DATE' class="auto-style1">
                                <script>
                                    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                var day = currentDate.getDate() - 1
                var month = currentDate.getMonth() + 1
                var year = currentDate.getFullYear()
                document.write("<b>" + day + "/" + month + "/" + year + "</b>")
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <td class="auto-style1">User_77407</td>
                            <td class="auto-style1"><script>document.write(ramdomPaymentMethod());</script></td>
                            <td class="auto-style1">$ 21,198</td>
                            <td id='DATE' class="auto-style1">
                                <script>
                                    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                var day = currentDate.getDate() - 1
                var month = currentDate.getMonth() + 1
                var year = currentDate.getFullYear()
                document.write("<b>" + day + "/" + month + "/" + year + "</b>")
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <td class="auto-style1">User_34907</td>
                            <td class="auto-style1"><script>document.write(ramdomPaymentMethod());</script></td>
                            <td class="auto-style1">$ 22,721</td>
                            <td id='DATE' class="auto-style1">
                                <script>
                                    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                var day = currentDate.getDate() - 1
                var month = currentDate.getMonth() + 1
                var year = currentDate.getFullYear()
                document.write("<b>" + day + "/" + month + "/" + year + "</b>")
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <td class="auto-style1">User_54960</td>
                            <td class="auto-style1"><script>document.write(ramdomPaymentMethod());</script></td>
                            <td class="auto-style1">$ 19,348</td>
                            <td id='DATE' class="auto-style1">
                                <script>
                                    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                var day = currentDate.getDate() - 1
                var month = currentDate.getMonth() + 1
                var year = currentDate.getFullYear()
                document.write("<b>" + day + "/" + month + "/" + year + "</b>")
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <td class="auto-style1">User_33832</td>
                            <td class="auto-style1"><script>document.write(ramdomPaymentMethod());</script></td>
                            <td class="auto-style1">$ 21,352</td>
                            <td id='DATE' class="auto-style1">
                                <script>
                                    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                var day = currentDate.getDate() - 1
                var month = currentDate.getMonth() + 1
                var year = currentDate.getFullYear()
                document.write("<b>" + day + "/" + month + "/" + year + "</b>")
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <td class="auto-style1">User_13480</td>
                            <td class="auto-style1"><script>document.write(ramdomPaymentMethod());</script></td>
                            <td class="auto-style1">$ 26,862</td>
                            <td id='DATE' class="auto-style1">
                                <script>
                                    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                var day = currentDate.getDate() - 1
                var month = currentDate.getMonth() + 1
                var year = currentDate.getFullYear()
                document.write("<b>" + day + "/" + month + "/" + year + "</b>")
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <td class="auto-style1">User_47205</td>
                            <td class="auto-style1"><script>document.write(ramdomPaymentMethod());</script></td>
                            <td class="auto-style1">$ 24,993</td>
                            <td id='DATE' class="auto-style1">
                                <script>
                                    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                var day = currentDate.getDate() - 1
                var month = currentDate.getMonth() + 1
                var year = currentDate.getFullYear()
                document.write("<b>" + day + "/" + month + "/" + year + "</b>")
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <td class="auto-style1">User_63594</td>
                            <td class="auto-style1"><script>document.write(ramdomPaymentMethod());</script></td>
                            <td class="auto-style1">$ 14,036</td>
                            <td id='DATE' class="auto-style1">
                                <script>
                                    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                var day = currentDate.getDate() - 1
                var month = currentDate.getMonth() + 1
                var year = currentDate.getFullYear()
                document.write("<b>" + day + "/" + month + "/" + year + "</b>")
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <td class="auto-style1">User_68097</td>
                            <td class="auto-style1"><script>document.write(ramdomPaymentMethod());</script></td>
                            <td class="auto-style1">$ 11,045</td>
                            <td id='DATE' class="auto-style1">
                                <script>
                                    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                var day = currentDate.getDate() - 1
                var month = currentDate.getMonth() + 1
                var year = currentDate.getFullYear()
                document.write("<b>" + day + "/" + month + "/" + year + "</b>")
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <td class="auto-style1">User_76103</td>
                            <td class="auto-style1"><script>document.write(ramdomPaymentMethod());</script></td>
                            <td class="auto-style1">$ 17,334</td>
                            <td id='DATE' class="auto-style1">
                                <script>
                                    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                var day = currentDate.getDate() - 1
                var month = currentDate.getMonth() + 1
                var year = currentDate.getFullYear()
                document.write("<b>" + day + "/" + month + "/" + year + "</b>")
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <td class="auto-style1">User_79723</td>
                            <td class="auto-style1"><script>document.write(ramdomPaymentMethod());</script></td>
                            <td class="auto-style1">$ 9,965</td>
                            <td id='DATE' class="auto-style1">
                                <script>
                                    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                var day = currentDate.getDate() - 1
                var month = currentDate.getMonth() + 1
                var year = currentDate.getFullYear()
                document.write("<b>" + day + "/" + month + "/" + year + "</b>")
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <td class="auto-style1">User_38426</td>
                            <td class="auto-style1"><script>document.write(ramdomPaymentMethod());</script></td>
                            <td class="auto-style1">$ 13,385</td>
                            <td id='DATE' class="auto-style1">
                                <script>
                                    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                var day = currentDate.getDate() - 1
                var month = currentDate.getMonth() + 1
                var year = currentDate.getFullYear()
                document.write("<b>" + day + "/" + month + "/" + year + "</b>")
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <td class="auto-style1">User_76582</td>
                            <td class="auto-style1"><script>document.write(ramdomPaymentMethod());</script></td>
                            <td class="auto-style1">$ 10,352</td>
                            <td id='DATE' class="auto-style1">
                                <script>
                                    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                var day = currentDate.getDate() - 1
                var month = currentDate.getMonth() + 1
                var year = currentDate.getFullYear()
                document.write("<b>" + day + "/" + month + "/" + year + "</b>")
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <td class="auto-style1">User_19713</td>
                            <td class="auto-style1"><script>document.write(ramdomPaymentMethod());</script></td>
                            <td class="auto-style1">$ 23,560</td>
                            <td id='DATE' class="auto-style1">
                                <script>
                                    var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                var day = currentDate.getDate() - 1
                var month = currentDate.getMonth() + 1
                var year = currentDate.getFullYear()
                document.write("<b>" + day + "/" + month + "/" + year + "</b>")
                                </script>
                            </td>
                        </tr>
                    </tbody>
                    </table>
                </div>
                </div>
            </div>  

</section>
</font>
        </div> <!-- end table column responsive small division -->
        
      <!-- ====================WITHDRAWAL SECTION -======================== -->
      
    <!-- ========================================================= End latest Trade option ===================================================== -->



 
   </section> 

  
 
            
</div>

  


@endsection