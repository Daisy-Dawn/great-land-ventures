@extends('layouts.base')


@inject('content', 'App\Http\Controllers\FrontController')
@section('content')
<!-- =============================Wrapper========================================================== -->
  <section class="wrapper">
    <section class="container-fluid bg-market">
          <div class="row">
            <div class="col-6 abt-us-txt">
              <h2 class="p-20 white">   Forex  </h2>
            </div>

       
          </div>

          <!-- the body section that contain the text =============== -->
          
        </section>
    <!-- ============BREADCUMB================== -->
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index" class="lite-ash">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Forex</li>
      </ol>
    </nav>
    <br>
    <section class="container-fluid">
      <div class="row">
        <div class="col-md-8 col-sm-12 col-crypto">
          <div class="container">
            <br />
             <h2 class="p-20 white">  Forex  </h2>

            <img src="{{$settings->site_address}}/public/images/item-forex.jpg" >
            <div style="padding: 20px;">
              <h3> <b> Online Forex Trading</b></h3>
              <p class="t-p">Foreign Exchange trading, also known as Forex or FX trading, has gained enormous popularity in recent years among layman individuals due to the growth of online brokers and the technological development of online trading platforms. With high liquidity, non-stop opening hours 5 days a week, and great opportunities, it is no wonder that the forex market is the world’s most traded market with a daily trading volume of $5 trillion USD.</p>
              <br />

              <h3> <b> What is FX Trading?</b></h3>
              <p class="t-p">When trading Forex, you are buying one currency by using another. Therefore, the FX trader is trading currency pairs and not each currency individually. Take for example the EURUSD, when buying the pair – it means you are buying EUR using (selling) USD. When selling the pair – it means you are buying USD using (selling) EUR.</p>
              <br />

              <p>Discover all the advantages of trading forex with {{$settings->site_name}} </p>
              <br />
              <ul class="crypto-list">
                <li> <i class="fas fa-arrow-right"></i> <b> Start trading with as little as $500</b> </li>
                <li> <i class="fas fa-arrow-right"></i> <b> Trade with confidence </b>– {{$settings->site_name}} is an internationally regulated broker. </li>
                <li> <i class="fas fa-arrow-right"></i> <b> No risk of wallet hacking or theft   </b> </li>
                <li> <i class="fas fa-arrow-right"></i> <b> Best in class customer service</b> – 24/5 multi-lingual live support.</li>
              </ul>

              <div class="clear-fix"></div>
        
              
            </div>
          </div> <!-- end container -->
          
          
          
        </div> <!-- end column-->

        <div class="col-md-4 col-sm-12">
          <div class="pad-55"></div>
          <div class="container">
            <div class="crypto-cat">
              <a href="crypto"> <div> Cryptocurrencies</div> </a>
              <a href="indices"> <div> Indices</div> </a>
              <div class="current-crypto">  <p> <i class="fas fa-arrow-alt-circle-right"></i> &nbsp Forex</p></div>
              <a href="commodities"> <div> Commodities</div> </a>
              <a href="shares"> <div> Shares</div> </a>
              <a href="options"> <div> Options</div> </a>
              <a href="etfs"> <div> ETFs</div> </a>
              <br />


               <div class="crypto-form"> 
                <h3 class="text-center"> Have a Question?  </h3>
                <form>
                <div class="form-group">
                  <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Your Name">
                </div>

                <div class="form-group">
                  <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Email*">
                </div>

                 <div class="form-group">
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                  </div>

                <button type="submit" class="plan-signup-crypto">Submit</button>
              </form>
              </div>            </div>
            
          </div>

              
        </div> <!-- end the container --> 

        
      </div><!-- end row -->
      
    </section>
    @endsection