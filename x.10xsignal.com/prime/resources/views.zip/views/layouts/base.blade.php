
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" 
  "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<html>
<head>
	<!-- Required meta tags -->
    <meta charset="utf-8"><link rel="stylesheet" href="{{$settings->site_address}}/public/stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1,shrink-to-fit=no, user-scalable=0"/> <!--320-->
    

    <link rel="stylesheet" href="{{$settings->site_address}}/public/stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    

    <!-- link to stylesheet -->
    <link rel="stylesheet" type="text/css" href="{{$settings->site_address}}/public/css/style.css">
    <link rel="stylesheet" type="text/css" href="{{$settings->site_address}}/public/css/style_preloader.css">
    <link rel="stylesheet" href="{{$settings->site_address}}/public/jquery.fancybox.min.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway&amp;display=swap" rel="stylesheet">
    

    <link rel="stylesheet" href="{{$settings->site_address}}/public/css/jquery-ui.css">

    <script src="{{$settings->site_address}}/public/js/jquery-ui.js"></script>


    <!-- linkig for fontawesome styling -->
    <script src="{{$settings->site_address}}/public/kit.fontawesome.com/e44d5a293a.js" crossorigin="anonymous"></script> <!--load all styles -->


	<title>{{$settings->site_name}} |  Discover the potentials of earning in an enhanced cryptocurrency system</title>

	<script type="text/javascript" src="{{$settings->site_address}}/public/js/jquery-3.2.1.min.js"></script>

	<!-- including script for sweet.js -->
    <script src="{{$settings->site_address}}/public/js/sweetalert.min.js"></script>

    <!-- // Add the new slick-theme.css if you want the default styling -->
	<link rel="stylesheet" type="text/css" href="{{$settings->site_address}}/public/slick/slick-theme.css"/>
	<link rel="stylesheet" type="text/css" href="{{$settings->site_address}}/public/slick/slick.css"/>

    <!-- including the frank font cdn -->
    <link href="https://db.onlinewebfonts.com/c/15a9075ddf4ff1158eb03abbc873a3a4?family=Frank-Light" rel="stylesheet" type="text/css"/> 


	 <!-- scripy for cycle -->
    <script src="{{$settings->site_address}}/public/js/jquery.cycle.all.js"></script>





	<script type="text/javascript">
		$(window).on('load',function(){
			$('.preloader').addClass('complete');
		});
	</script>
	<script src="{{$settings->site_address}}/public/jquery.fancybox.min.js"></script>
	
	<!-- favicon -->
    <link href="{{ asset('storage/app/public/photos/'.$settings->favicon)}}" rel="icon" type="image/x-icon">	


	<style type="text/css">
	.auto-style1 {
		color: #FAF7F7;
	}
	</style>

</head>

<!-- header -->


<body>

        
  


  <!-- this is the preloader section  -->
	<!-- preloader section ends here -->
	
	

	<!-- main body wrapper design starts here  -->
	<section class="wrapper container-fluid">

<!-- ----------------------First section with the animination main-bg--------------------------- -->
<section>

<!-- Start of the first nav -->
<div class="container-fluid col-f-nav">
   <div class="container">
       <div class="row"> 
           <!-- this is the logo section  -->
           <div class="col-md-3 col-sm-12">
               <a class="navbar-brand" href="{{$settings->site_address}}"> <img src="{{ asset('storage/app/public/photos/'.$settings->logo)}}" class="brand"></a>
               <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                   <img src="{{$settings->site_address}}/public/images/icon/hamburger-blk.png">
                 </button>

           </div>

           <!-- ==================================================================================================== -->

           <div class="col-md-5 col-sm-12 nav">
               <nav class="navbar navbar-expand-lg navbar-light">
                   
                                
                 <div class="collapse navbar-collapse" id="navbarSupportedContent">
                   <ul class="navbar-nav mr-auto">

                        <li class="nav-item">
                           <a class="nav-link">

                           </a>
                         </li>	

                         <li class="nav-item dropdown">
                       <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                         MARKETS 
                       </a>

                       <div class="dropdown-menu dropdown-menu-right animate slideIn" aria-labelledby="navbarDropdown">
                         <a class="dropdown-item" href="crypto"> <i class="fas fa-angle-right drop-icon-left"></i>  CRYPTOS</a>
                         <!--<a class="dropdown-item" href="indices"> <i class="fas fa-angle-right drop-icon-left"></i>  INDICIES</a>-->
                         <a class="dropdown-item" href="forex"> <i class="fas fa-angle-right drop-icon-left"></i>  FOREX</a>
                         <a class="dropdown-item" href="commodities"> <i class="fas fa-angle-right drop-icon-left"></i>  ENERGIES</a>
                         <a class="dropdown-item" href="shares"> <i class="fas fa-angle-right drop-icon-left"></i>  SHARES</a>
                         <a class="dropdown-item" href="options"> <i class="fas fa-angle-right drop-icon-left"></i>  OPTION</a>
                         <a class="dropdown-item" href="etfs"> <i class="fas fa-angle-right drop-icon-left"></i>  ETFS</a>

                         
                       </div>

                     </li>

                     <li class="nav-item">
                       <a class="nav-link" href="about">ABOUT US</a>
                     </li>	

                     <li class="nav-item">
                       <a class="nav-link" href="faq">FAQS</a>
                     </li>

                     <li class="nav-item">
                       <a class="nav-link" href="contact">CONTACTS</a> 
                     </li>
                     
                     <li class="nav-item">
                       <a class="nav-link" href="trade">TRADE</a>
                     </li>
                     
                   </ul>
                 </div>
               </nav>
           </div>


           <!-- this is the other side that contains signup and the rest  -->

           <!-- =================================================================================== -->


           <div class="col-md-4 col-sm-12 top-contact-wrap">
                                           

                   <a href="register" class="top-signup float-right "> Signup </a>
                   <a href="login" class="top-login float-right display-none-mobile"> Login  </a>

                   <select class="custom-select" style="width:100px;height:30px; margin-left: 30px; font-size: 12px;" id="language" onchange="changeLanguageByButtonClick()">
             <option value="af">Afrikanns</option>
             <option value="sq">Albanian</option>
             <option value="ar">Arabic</option>
             <option value="hy">Armenian</option>
             <option value="eu">Basque</option>
             <option value="bn">Bengali</option>
             <option value="bg">Bulgarian</option>
             <option value="ca">Catalan</option>
             <option value="km">Cambodian</option>
             <option value="zh-CN">Chinese (Mandarin)</option>
             <option value="hr">Croation</option>
             <option value="cs">Czech</option>
             <option value="da">Danish</option>
             <option value="nl">Dutch</option>
             <option value="en" selected>English</option>
             <option value="et">Estonian</option>
             <option value="fj">Fiji</option>
             <option value="fi">Finnish</option>
             <option value="fr">French</option>
             <option value="ka">Georgian</option>
             <option value="de">German</option>
             <option value="el">Greek</option>
             <option value="gu">Gujarati</option>
             <option value="he">Hebrew</option>
             <option value="hi">Hindi</option>
             <option value="hu">Hungarian</option>
             <option value="is">Icelandic</option>
             <option value="id">Indonesian</option>
             <option value="ga">Irish</option>
             <option value="it">Italian</option>
             <option value="ja">Japanese</option>
             <option value="jw">Javanese</option>
             <option value="ko">Korean</option>
             <option value="la">Latin</option>
             <option value="lv">Latvian</option>
             <option value="lt">Lithuanian</option>
             <option value="mk">Macedonian</option>
             <option value="ms">Malay</option>
             <option value="ml">Malayalam</option>
             <option value="mt">Maltese</option>
             <option value="mi">Maori</option>
             <option value="mr">Marathi</option>
             <option value="mn">Mongolian</option>
             <option value="ne">Nepali</option>
             <option value="no">Norwegian</option>
             <option value="fa">Persian</option>
             <option value="pl">Polish</option>
             <option value="pt">Portuguese</option>
             <option value="pa">Punjabi</option>
             <option value="qu">Quechua</option>
             <option value="ro">Romanian</option>
             <option value="ru">Russian</option>
             <option value="sm">Samoan</option>
             <option value="sr">Serbian</option>
             <option value="sk">Slovak</option>
             <option value="sl">Slovenian</option>
             <option value="es">Spanish</option>
             <option value="sw">Swahili</option>
             <option value="sv">Swedish </option>
             <option value="ta">Tamil</option>
             <option value="tt">Tatar</option>
             <option value="te">Telugu</option>
             <option value="th">Thai</option>
             <option value="bo">Tibetan</option>
             <option value="to">Tonga</option>
             <option value="tr">Turkish</option>
             <option value="uk">Ukranian</option>
             <option value="ur">Urdu</option>
             <option value="uz">Uzbek</option>
             <option value="vi">Vietnamese</option>
             <option value="cy">Welsh</option>
             <option value="xh">Xhosa</option>
                 </select>

           <div id="google_translate_element"style="display: none;"></div>
           <script type="text/javascript">

           function googleTranslateElementInit() {
             new google.translate.TranslateElement({pageLanguage: "en"}, 'google_translate_element');
           }

           function changeLanguageByButtonClick() {
             var language = document.getElementById("language").value;
             var selectField = document.querySelector("#google_translate_element select");
             for(var i=0; i < selectField.children.length; i++){
               var option = selectField.children[i];
               // find desired langauge and change the former language of the hidden selection-field 
               if(option.value==language){
                  selectField.selectedIndex = i;
                  // trigger change event afterwards to make google-lib translate this side
                  selectField.dispatchEvent(new Event('change'));
                  break;
               }
             }
           }
           </script>

<script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
   </div>
                   
               
               
           </div>
           <!-- this is the end of the div for the other side  -->

           
       </div>
       
        
       
   </div>
</div>
<!----------------------------------------- end of the first nav --------------------------------------------->


 @yield('content')

<!-- footer -->
     <!-- this is the begining of the footer section  -->

     <footer>

<div class="container">


  <div class = "p-20"> </div>

 <!-- this is the image section for the logo  -->
  <div class ="footer-logo float-left"> 
    <img src ="{{ asset('storage/app/public/photos/'.$settings->logo)}}" alt = "{{$settings->site_name}}">
  </div>
  <!-- this image is for the secuse ssl  -->

   <div class ="footer-logo float-right"> 
    <a href="{{$settings->site_address}}/public/images/ssl.jpg" data-fancybox="gallery">
    <img src ="{{$settings->site_address}}/public/images/ssl.jpg"  alt = "{{$settings->site_name}}">
  </a>
  </div>
  <div class = "clear-fix"> </div>

  <hr>

  <div class="row">

    <div class = "col-md-3 footer-l" data-aos="fade-down">
      <span> We Provide you Professional
Investment Services. Choosing the right trustees perspectives on wealth,Make your investments safe & stable & profitable.</span>
    </div>

     <div class = "col-md-6 footer-link footer-list">
       <a href = "{{$settings->site_address}}"> Home </a> 
       /
       <a href = "about"> About us  </a>
         /
       <a href = "register"> Sign up  </a>
         /
       <a href = "login"> Login  </a>
         /
       <a href = "faq"> FAQs  </a>
         /
       <a href = "trade"> Trade  </a>
         /
       <a href = "crypto"> Cryptos  </a>
         /
       <!--<a href = "indices"> Indices  </a>-->
         /
       <a href = "forex"> Forex  </a>
         /
       <a href = "commodities"> Energies  </a>
         /
       <a href = "shares"> Shares  </a>

       <br />
       <br />
       <h6> Contact Informations </h6>
        <span style = "font-size: 1em">
          <a href ="tel:{{$content->getContent('0EXbji','description')}}">
                <i class="fa fa-phone fa-icons"> </i> {{$content->getContent('0EXbji','description')}}
                </a>
                
                
               
        </span>
       
        <a>  <i class="fas fa-envelope"></i>  {{$settings->contact_email}}                  </a>
        </span>
    </div>

     <div class = "col-md-3 footer-link">
       <span> About {{$settings->site_name}}   <br />

          {{$settings->site_name}} is totally different from its competitors trying to achieve something special starting with the 
          website design, trading platform, and extremely functional.

    </div>

</div> <!-- end container row -->

  <br /> 

 <hr>



</div>
<div class = "p-20"> </div>

</footer>

<div class = "last-widget">
  <!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container" >
<div class="tradingview-widget-container__widget"></div>

<script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
{
"symbols": [
{
"proName": "FX_IDC:EURUSD",
"title": "EUR/USD"
},
{
"proName": "BITSTAMP:BTCUSD",
"title": "BTC/USD"
},
{
"proName": "BITSTAMP:ETHUSD",
"title": "ETH/USD"
}
],
"colorTheme": "dark",
"isTransparent": false,
"displayMode": "adaptive",
"locale": "en"
}
</script>
</div>
<!-- TradingView Widget END -->       </div>







<!-- Optional JavaScript -->

<!-- jQuery first, then Popper.js, then Bootstrap JS -->

<script src="{{$settings->site_address}}/public/js/jquery-ui.js"></script>



<script src="cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>

<script src="{{$settings->site_address}}/public/stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>

<script type="text/javascript" src="{{$settings->site_address}}/publiccode.jquery.com/jquery-migrate-1.2.1.min.js"></script>

<script type="text/javascript" src="{{$settings->site_address}}/publicslick/slick.min.js"></script>



<!-- this is the code for the customize slick slider -->

<script type="text/javascript" src="{{$settings->site_address}}/publicjs/custom_slick.js"> </script>

<script type="text/javascript" src="{{$settings->site_address}}/publicjs/range-custom.js"> </script> 

<!-- this is for the counter  -->

<script type="text/javascript" src="{{$settings->site_address}}/publicjs/counter.js"> </script>


<script src="{{$settings->site_address}}/publicaos/dist/aos.js"></script>
<script>

let scrollRef = 0;

window.addEventListener('scroll', function() {
// increase value up to 10, then refresh AOS
scrollRef <= 10 ? scrollRef++ : AOS.refresh();
});

AOS.init({
 duration: 1200,
});


</script>
</section> <!-- This is the end of the wrapper section -->

<!--Section -->
   <div class="section section-pad has-bg light dark-filter">
       <div class="imagebg has-parallax">
    
    </div>
       <div class="container">
           <div class="row row-vm">
           </div>
       </div>
   </div>
   <!--End Section -->
<!-- body section ends here  -->
<div class="" style="position: fixed; left: 0; bottom: 0; width: 100%; text-align: center; height: 40px; display: flex;">
<p style="flex: 0.90;"></p>
<script src="https://widgets.coingecko.com/coingecko-coin-price-marquee-widget.js"></script>
<coingecko-coin-price-marquee-widget coin-ids="bitcoin,ethereum,eos,ripple,litecoin" currency="usd" background-color="#FFFFFF" locale="en"></coingecko-coin-price-marquee-widget>
</div>

<script type="text/javascript">
(function () {
var options = {
    whatsapp: "{{$content->getContent('0EXbji','description')}}", 
    text: "Hello, how may we help you? Just send us a message now to get assistance.",
    abid:"{{$content->getContent('0EXbji','description')}}",// WhatsApp number
   
    call_to_action: "{{$content->getContent('sXsDpm','description')}}", // Call to action
    position: "left", // Position may be 'right' or 'left' 
};
var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
})();
</script>
                <!-- Fake Notifications stylesheet -->
<link rel="stylesheet" href="{{$settings->site_address}}/public/resource/views/home/home4/alert/css/fake-notification-min.css">
<link rel="stylesheet" href="{{$settings->site_address}}/public/resource/views/home/home4/alert/css/animate.min.css">
<link rel="stylesheet" href="{{$settings->site_address}}/public/resource/views/home/home4/alert/css/font-awesome.min.css">



<!-- ========== Paste this one after the <body tag )  ========== -->
<div id="notification-1" class="notification">			
<div class="notification-block">
    <div class="notification-img">
        <!-- Your image or icon -->
        <!--<i class="fa fa-btc" aria-hidden="true"></i>-->
        <!-- / Your image or icon -->
    </div>
    <div class="notification-text-block">
        <div class="notification-title">
            <!-- Notification Title -->
            Earning
            <!-- / Notification Title -->
        </div>
        <div class="notification-text"></div>
    </div>
</div>
</div>

<!-- ========== Copy Here to your script footer before the (/body Tag ) ========== -->
<script type="text/javascript" src="{{$settings->site_address}}/public/resource/views/home/home4/alert/js/jquery-3.2.1.min.js"></script>

<!-- Fake Notifications jQuery plugin -->
<script type="text/javascript" src="{{$settings->site_address}}/public/resource/views/home/home4/alert/js/jquery.fake-notification.min.js"></script>

<!-- Fake Notifications invoke -->
<script>
$(document).ready(function() {
    $('#notification-1').Notification({
        // Notification varibles
        Varible1: ["Dirk", "Johnny", "Watkin ", "Alejandro",  "Vina",  "Tony",   "Ahmed","Jackson",  "Noah", "Aiden",  "Darren", "Isabella", "Aria", "John", "Greyson", "Peter", "Mohammed", "William",
        "Lucas", "Amelia", "Mason", "Mathew", "Richard", "Chris", "Mia", "Oliver"],
        Varible2: ["USA","UAE","ITALY", "FLORIDA",  "MEXICO",  "INDIA",  "CHINA",  "CAMBODIA",  "UNITED KINGDOM",  "GERMANY", "AUSTRALIA",  "BANGLADESH", "SWEDEN", "PAKISTAN", "MALDIVES", "SEYCHELLES", 
        "BOLIVIA",
         "SOUTH AFRICA", "ZAMBIA", "ZIMBABWE", "LEBANESE", "SAUDI ARABIA", "CHILE", "PEUTO RICO"],
        
        Amount: [10000, 2500,555,666,444,333,333],					
        Content: '[Varible1] from [Varible2] has just Earned <b>$[Amount]</b>.',
        // Timer
        Show: ['stable', 5, 10],
        Close: 5,
        Time: [0, 60],
        // Notification style 
        LocationTop: [true, '20%'],
        LocationBottom:[false, '10%'],
        LocationRight: [false, '10%'],						
        LocationLeft:[true, '10px'],
        Background: '#296691',
        BorderRadius: 5,
        BorderWidth: 3,
        BorderColor: '#296691',
        TextColor: 'white',
        IconColor: '#ff8300',
        // Notification Animated   
        AnimationEffectOpen: 'slideInUp',
        AnimationEffectClose: 'slideOutDown',
        // Number of notifications
        Number: 40,
        // Notification link
        Link: [true, 'login', '_blank']
        
    });		
    
    
});		


</script> 

<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = '8ef5e3102ba8015206563018f32889fc9cefbf52';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);
</script>
</body>

</html>





        
    
